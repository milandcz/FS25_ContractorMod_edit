cmPlayer = {}

function cmPlayer:onLeaveVehicle(superfunc, vehicle, noEventSend)
    if ContractorMod.debug then print(string.format("cmPlayer.onLeaveVehicle vehicle=%s", vehicle and (vehicle.getName and vehicle:getName() or tostring(vehicle)) or "nil")) end
    local currentVehicle = g_localPlayer:getCurrentVehicle()
    if currentVehicle then
        cmPlayer:ManageLeaveVehicle(currentVehicle)
    end
    superfunc(self, vehicle, noEventSend)
end
Player.leaveVehicle = Utils.overwrittenFunction(Player.leaveVehicle, cmPlayer.onLeaveVehicle)

-- Stop AIJob when leaving vehicle with worker as driver in it
function cmPlayer:ManageLeaveVehicle(controlledVehicle)
    if ContractorMod.debug then print("cmPlayer:ManageLeaveVehicle") end
    
    if controlledVehicle ~= nil then
        local currentWorker = ContractorMod.workers[ContractorMod.currentID]
        if currentWorker ~= nil and ContractorMod.shouldStopWorker and currentWorker.currentSeat == nil then
            local rootVehicle = controlledVehicle
            if controlledVehicle.getRootVehicle ~= nil then
                local root = controlledVehicle:getRootVehicle()
                if root ~= nil then
                    rootVehicle = root
                end
            end
            if ContractorMod.stopVehicleWork ~= nil and ContractorMod:stopVehicleWork(rootVehicle) then
                g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, g_i18n:getText("ContractorMod_WORKER_STOP"))
            end
        end
    end

end

-- Prevent to teleport to exit point when switching between workers
function cmPlayer:teleportToExitPoint(superfunc, vehicle, noEventSend)
    if ContractorMod.debug then print("cmPlayer:teleportToExitPoint") end
    -- printCallstack()
    if not ContractorMod.switching then
        superfunc(self, vehicle, noEventSend)
    end
end
Player.teleportToExitPoint = Utils.overwrittenFunction(Player.teleportToExitPoint, cmPlayer.teleportToExitPoint)

-- Draw worker name above head when not in vehicle
function cmPlayer:drawUIInfo(superfunc)
	if (ContractorMod.displayPlayerNames and not g_gui:getIsGuiVisible() and (not g_noHudModeEnabled and (g_gameSettings:getValue(GameSettings.SETTING.SHOW_MULTIPLAYER_NAMES) ))) then
        local x1, y1, z1 = getWorldTranslation(g_cameraManager:getActiveCamera())
        for i, worker in pairs(ContractorMod.workers) do
            if ContractorMod:getWorkerVehicle(worker) == nil and worker.index ~= ContractorMod.currentID and worker.npc ~= nil then
                local x, y, z = getTranslation(worker.npc.playerGraphics.graphicsRootNode)
                local diffX = x - x1
                local diffY = y - y1
                local diffZ = z - z1
                if MathUtil.vector3LengthSq(diffX, diffY, diffZ) <= 10000 then
                    local y = y + worker.npc.playerGraphics.nameTagOffsetY
                    Utils.renderTextAtWorldPosition(x, y, z, worker.name, getCorrectTextSize(0.02), 0)
                end
            end
        end
	end
end
Player.drawUIInfo = Utils.appendedFunction(Player.drawUIInfo, cmPlayer.drawUIInfo)

-- Prevent to spawn vehicle on mission start
function cmPlayer:getHasSpawnVehicle(superfunc)
	if ContractorMod.workers ~= nil then
        return ContractorMod.workers[1] ~= nil and ContractorMod.workers[1].currentVehicle ~= nil
    end
    return false
end
Player.getHasSpawnVehicle = Utils.overwrittenFunction(Player.getHasSpawnVehicle, cmPlayer.getHasSpawnVehicle)
